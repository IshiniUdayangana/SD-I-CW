import json
import datetime

# Global dictionary to store transactions
transactionsB = {"Groceries" : [], "Salary" : [], "Utilities" : [], "Transport" : [], "Other Income" : [], "Other Expense" : []}

'''Open a JSON file in read mode and if it is not, handle the error'''

# File handling functions
def load_transactions():
    global transactionsB
    while True:
        try:
            with open("transactionsB.json", "r") as file:
                return json.load(file)
        except FileNotFoundError:
            return{}

'''Open the JSON file in write mode and create a function to save the transactions to the JSON file '''

def save_transactions():
        with open("transactionsB.json", "w") as file:
            json.dump(transactionsB, file)

def read_bulk_transactions_from_file(filename):
    global transactionsB
    try:
        with open(filename, "r") as file:
            for line in file:
                date, add_choice, amount = line.strip().split(",")
                add_choice = int(add_choice)
                amount = float(amount)
                
                # Map add_choice to category
                category = ""
                if add_choice == 1:
                    category = "Groceries"
                elif add_choice == 2:
                    category = "Salary"
                elif add_choice == 3:
                    category = "Utilities"
                elif add_choice == 4:
                    category = "Transport"
                elif add_choice == 5:
                    category = "Other Expense"
                elif add_choice == 6:
                    category = "Other Income"

                # Add transaction to the corresponding category
                transactionsB[category].append({"amount": amount, "date": date})
    except FileNotFoundError:
        print("File not found!")

        
# Feature implementations
def add_transaction():
    global transactionsB
    while True:
        print("1. Groceries")
        print("2. Salary")
        print("3. Utilities")
        print("4. Transport")
        print("5. Other Expense")
        print("6. Other Income")

        try:
            add_choice = input("\nPlease select the category to add the transaction : ")
        except ValueError:
            print("\nInvalid Input! Please input valid number\n")

        if add_choice == "1":
        
            while True:
                try:
                    amount = float(input("Enter amount of groceries : "))
                except ValueError:
                    print("\nPlease input numeric value!\n")
                    continue
                else:
                    break
                
            while True:    
                is_today = input("Did you make this transaction today(Yes / No)? : ")
                is_today = is_today.lower()
                if is_today == "yes":
                    today = datetime.datetime.now().date()
                    date = str(today) 
                    break
                elif is_today == "no":
                    date = input("Enter the date in YYYY-MM-DD format : ")
                    break
                else:
                    print("Please input yes or no")
                        
            transactionsB["Groceries"].append({"amount" : amount, "date" : date})
            save_transactions()
            print("\nTransaction added successfully!\n")
            break

        elif add_choice == "2":
            
            while True:
                try:
                    amount = float(input("Enter amount of salary : "))
                except ValueError:
                    print("\nPlease input numeric value!\n")
                    continue
                else:
                    break

            while True:
                is_today = input("Did you make this transaction today(Yes / No)? : ")
                is_today = is_today.lower()
                if is_today == "yes":
                    today = datetime.datetime.now().date()
                    date = str(today) 
                    break
                elif is_today == "no":
                    date = input("Enter the date in YYYY-MM-DD format : ")
                    break
                else:
                    print("Please input yes or no")

            transactionsB["Salary"].append({"amount" : amount, "date" : date})
            save_transactions()
            print("\nTransaction added successfully!")
            break

        elif add_choice == "3":
            
            while True:
                try:
                    amount = float(input("Enter amount of utilities : "))
                except ValueError:
                    print("\nPlease input numeric value!\n")
                    continue
                else:
                    break

            while True:    
                is_today = input("Did you make this transaction today(Yes / No)? : ")
                is_today = is_today.lower()
                if is_today == "yes":
                    today = datetime.datetime.now().date()
                    date = str(today) 
                    break
                elif is_today == "no":
                    date = input("Enter the date in YYYY-MM-DD format : ")
                    break
                else:
                    print("Please input yes or no")
            
            transactionsB["Utilities"].append({"amount" : amount, "date" : date})
            save_transactions()
            print("\nTransaction added successfully!")
            break

        elif add_choice == "4":
            
            while True:
                try:
                    amount = float(input("Enter amount of transport : "))
                except ValueError:
                    print("\nPlease input numeric value!\n")
                    continue
                else:
                    break

            while True:    
                is_today = input("Did you make this transaction today(Yes / No)? : ")
                is_today = is_today.lower()
                if is_today == "yes":
                    today = datetime.datetime.now().date()
                    date = str(today) 
                    break
                elif is_today == "no":
                    date = input("Enter the date in YYYY-MM-DD format : ")
                    break
                else:
                    print("Please input yes or no")
            
            transactionsB["Transport"].append({"amount" : amount, "date" : date})
            save_transactions()
            print("\nTransaction added successfully!")
            break

        elif add_choice == "5":
        
            while True:
                try:
                    amount = float(input("Enter amount of groceries : "))
                except ValueError:
                    print("\nPlease input numeric value!\n")
                    continue
                else:
                    break

            while True:    
                is_today = input("Did you make this transaction today(Yes / No)? : ")
                is_today = is_today.lower()
                if is_today == "yes":
                    today = datetime.datetime.now().date()
                    date = str(today) 
                    break
                elif is_today == "no":
                    date = input("Enter the date in YYYY-MM-DD format : ")
                    break
                else:
                    print("Please input yes or no")
                    
        
            transactionsB["Other Expense"].append({"amount" : amount, "date" : date})
            save_transactions()
            print("\nTransaction added successfully!")
            break

        elif add_choice == "6":
        
            while True:
                try:
                    amount = float(input("Enter amount of other income : "))
                except ValueError:
                    print("\nPlease input numeric value!\n")
                    continue
                else:
                    break

            while True:    
                is_today = input("Did you make this transaction today(Yes / No)? : ")
                is_today = is_today.lower()
                if is_today == "yes":
                    today = datetime.datetime.now().date()
                    date = str(today) 
                    break
                elif is_today == "no":
                    date = input("Enter the date in YYYY-MM-DD format : ")
                    break
                else:
                    print("Please input yes or no")
        
            transactionsB["Other Income"].append({"amount" : amount, "date" : date})
            save_transactions()
            print("\nTransaction added successfully!")
            break

        else:
            print("\nPlease Enter valid range number!")

        

def view_transactions():
    global transactionsB
    while True:
        print("1. Groceries")
        print("2. Salary")
        print("3. Utilities")
        print("4. Transport")
        print("5. Other Expense")
        print("6. Other Income")

        try:
            view_choice = int(input("\nPlease select the category to view the transactions : "))
        except ValueError:
            print("\nInvalid Input! Please input valid number\n")
            continue

        number = 1
        if view_choice == 1:
            if "Groceries" in transactionsB:
                print("|Groceries Transactions|")
                num = 1
                for transactions in transactionsB["Groceries"]:
                    print(number, ".", "Date:",transactions["date"], ", Amount:", transactions["amount"])
                    number += 1
            else:
                print("No transactions found for groceries")
            break

        if view_choice == 2:
            if "Salary" in transactionsB:
                print("|Salary Transactions|")
                num = 1
                for transactions in transactionsB["Salary"]:
                    print(number, ".", "Date:",transactions["date"], ", Amount:", transactions["amount"])
                    number += 1
            else:
                print("No transactions found for salary")
            break

        if view_choice == 3:
            if "Utilities" in transactionsB:
                print("|Utilities Transactions|")
                num = 1
                for transactions in transactionsB["Utilities"]:
                    print(number, ".", "Date:",transactions["date"], ", Amount:", transactions["amount"])
                    number += 1
            else:
                print("No transactions found for utilities")
            break

        if view_choice == 4:
            if "Transport" in transactionsB:
                print("|Transport Transactions|")
                num = 1
                for transactions in transactionsB["Transport"]:
                    print(number, ".", "Date:",transactions["date"], ", Amount:", transactions["amount"])
                    number += 1
            else:
                print("No transactions found for transport")
            break

        if view_choice == 5:
            if "Other Expense" in transactionsB:
                print("|Other Expense Transactions|")
                num = 1
                for transactions in transactionsB["Other Expense"]:
                    print(number, ".", "Date:",transactions["date"], ", Amount:", transactions["amount"])
                    number += 1
            else:
                print("No transactions found for other expense")
            break


        if view_choice == 6:
            if "Other Income" in transactionsB:
                print("|Other Income Transactions|")
                num = 1
                for transactions in transactionsB["Other Income"]:
                    print(number, ".", "Date:",transactions["date"], ", Amount:", transactions["amount"])
                    number += 1
            else:
                print("No transactions found for other income")
            break


        else:
           print("Please input valid range number")
    
        
def update_transaction():
    global transactionsB

    # Displaying transaction categories
    print("Transaction Categories:")
    print("1. Groceries")
    print("2. Salary")
    print("3. Utilities")
    print("4. Transport")
    print("5. Other Expense")
    print("6. Other Income")

    try:
        category_choice = int(input("Select the category to update transaction: "))
    except ValueError:
        print("Invalid input! Please enter a valid number.")
        return

    # Checking if the selected category exists
    if category_choice not in range(1, 7):
        print("Invalid category choice!")
        return

    # Selecting the transaction to update
    view_transactions()
    try:
        transaction_number = int(input("Enter the transaction number to update: "))
    except ValueError:
        print("Invalid input! Please enter a valid number.")
        return

    category = ""
    if category_choice == 1:
        category = "Groceries"
    elif category_choice == 2:
        category = "Salary"
    elif category_choice == 3:
        category = "Utilities"
    elif category_choice == 4:
        category = "Transport"
    elif category_choice == 5:
        category = "Other Expense"
    elif category_choice == 6:
        category = "Other Income"
    
    # Checking if the selected transaction number is valid
    if transaction_number not in range(1, len(transactionsB[category]) + 1):
        print("Invalid transaction number!")
        return

    # Updating the transaction amount
    try:
        new_amount = float(input("Enter the new amount: "))
    except ValueError:
        print("Invalid input! Please enter a valid amount.")
        return

    transactionsB[category][transaction_number - 1]["amount"] = new_amount
    print("Transaction updated successfully!")
    save_transactions()

           
def delete_transaction():
    global transactionsB

    # Displaying transaction categories
    print("Transaction Categories:")
    print("1. Groceries")
    print("2. Salary")
    print("3. Utilities")
    print("4. Transport")
    print("5. Other Expense")
    print("6. Other Income")

    try:
        category_choice = int(input("Select the category to delete transaction: "))
    except ValueError:
        print("Invalid input! Please enter a valid number.")
        return

    # Checking if the selected category exists
    if category_choice not in range(1, 7):
        print("Invalid category choice!")
        return

    category = ""
    if category_choice == 1:
        category = "Groceries"
    elif category_choice == 2:
        category = "Salary"
    elif category_choice == 3:
        category = "Utilities"
    elif category_choice == 4:
        category = "Transport"
    elif category_choice == 5:
        category = "Other Expense"
    elif category_choice == 6:
        category = "Other Income"

    # Viewing transactions of the selected category
    view_transactions()

    try:
        transaction_number = int(input("Enter the transaction number to delete: "))
    except ValueError:
        print("Invalid input! Please enter a valid number.")
        return

    # Checking if the selected transaction number is valid
    if transaction_number not in range(1, len(transactionsB[category]) + 1):
        print("Invalid transaction number!")
        return

    # Deleting the transaction
    del transactionsB[category][transaction_number - 1]
    print("Transaction deleted successfully!")
    save_transactions()



def display_summary():
    global transactionsB
    total_income = 0
    total_expense = 0

    # Calculate total income
    if "Salary" in transactionsB:
        for transaction in transactionsB["Salary"]:
            total_income += transaction["amount"]

    if "Other Income" in transactionsB:
        for transaction in transactionsB["Other Income"]:
            total_income += transaction["amount"]

    # Calculate total expense
    if "Groceries" in transactionsB:
        for transaction in transactionsB["Groceries"]:
            total_expense += transaction["amount"]

    if "Utilities" in transactionsB:
        for transaction in transactionsB["Utilities"]:
            total_expense += transaction["amount"]

    if "Transport" in transactionsB:
        for transaction in transactionsB["Transport"]:
            total_expense += transaction["amount"]

    if "Other Expense" in transactionsB:
        for transaction in transactionsB["Other Expense"]:
            total_expense += transaction["amount"]

    # Print summary
    print("\n--- Summary ---")
    print("Total Income:", total_income)
    print("Total Expense:", total_expense)
    print("Net Balance:", total_income - total_expense)


def main_menu():
    load_transactions()
    while True:
        print("\n1. Add transaction")
        print("2. View transactions")
        print("3. Update transaction")
        print("4. Delete transaction")
        print("5. Display summary")
        print("6. Exit")
        try:
            choice = int(input("\nPlease enter your choice : "))
        except ValueError:
            print("\nInvalid input! \nPlease enter valid range numeric value.")
        if choice == 1:
            add_transaction()
        elif choice == 2:
            view_transactions()
        elif choice == 3:
            update_transaction()
        elif choice == 4:
            delete_transaction()
        elif choice == 5:
            display_summary()
        elif choice == 6:
            print("Exiting program.")
            break
        else:
            print("\nInvalid input!\nPlease enter valid range numeric number.")

if __name__ == "__main__":
    main_menu()


