import json
import datetime
import tkinter as tk
from tkinter import ttk
import json

# Global dictionary to store transactions
transactions = {"Groceries" : [], "Salary" : [], "Utilities" : [], "Transport" : [], "Other Income" : [], "Other Expense" : []}

'''Open a JSON file in read mode and if it is not, handle the error'''

# File handling functions
def load_transactions():
    global transactions
    while True:
        try:
            with open("transactions.json", "r") as file:
                return json.load(file)
        except FileNotFoundError:
            return{}

'''Open the JSON file in write mode and create a function to save the transactions to the JSON file '''

def save_transactions():
        with open("transactions.json", "w") as file:
            json.dump(transactions, file)

'''Ask for add transactions from filename.txt to transactions.json file, if it is append the data to json file'''

def read_bulk_transactions_from_file(filename):
    global transactions
    while True:
        load_bulk = input("Do you want to load bulk transactions from a file(Yes/No) : ")
        if load_bulk.lower() == "yes" :
            try:
                with open(filename, "r") as file:
                    for line in file:
                        date, category, amount = line.strip().split(",")
                        transactions[category].append({"amount": float(amount), "date": date})
                    save_transactions()
                    print("Transaction loaded successfully!")
                    break
            except FileNotFoundError:
                print("File not found!")
                break
        elif load_bulk.lower() == "no":
            break
        else:
            print("Invalid input. Please enter \"yes\" or \"no\" : ")

        
date = "None" 

def is_today_func():
    global date
    while True:    
            is_today = input("Did you make this transaction today(Yes / No)? : ")
            is_today = is_today.lower()
            if is_today == "yes":
                today = datetime.datetime.now().date()
                date = str(today)
                return date
                break
            elif is_today == "no":
                date = input("Enter the date in YYYY-MM-DD format : ")
                return date
                break
            else:
                print("Please input yes or no")
        
# Feature implementations
def add_transaction():
    global date
    global transactions
    while True:
        print("1. Groceries")
        print("2. Salary")
        print("3. Utilities")
        print("4. Transport")
        print("5. Other Expense")
        print("6. Other Income")

        try:
            add_choice = input("\nPlease select the category to add the transaction : ")
        except ValueError:
            print("\nInvalid Input! Please input valid number\n")

        if add_choice == "1":
        
            while True:
                try:
                    amount = float(input("Enter amount of groceries : "))
                except ValueError:
                    print("\nPlease input numeric value!\n")
                    continue
                else:
                    break
                
            is_today_func()
                        
            transactions["Groceries"].append({"amount" : amount, "date" : date})
            save_transactions()
            print("\nTransaction added successfully!\n")
            break

        elif add_choice == "2":
            
            while True:
                try:
                    amount = float(input("Enter amount of salary : "))
                except ValueError:
                    print("\nPlease input numeric value!\n")
                    continue
                else:
                    break

            is_today_func()

            transactions["Salary"].append({"amount" : amount, "date" : date})
            save_transactions()
            print("\nTransaction added successfully!")
            break

        elif add_choice == "3":
            
            while True:
                try:
                    amount = float(input("Enter amount of utilities : "))
                except ValueError:
                    print("\nPlease input numeric value!\n")
                    continue
                else:
                    break

            is_today_func()
            
            transactions["Utilities"].append({"amount" : amount, "date" : date})
            save_transactions()
            print("\nTransaction added successfully!")
            break

        elif add_choice == "4":
            
            while True:
                try:
                    amount = float(input("Enter amount of transport : "))
                except ValueError:
                    print("\nPlease input numeric value!\n")
                    continue
                else:
                    break

            is_today_func()
            
            transactions["Transport"].append({"amount" : amount, "date" : date})
            save_transactions()
            print("\nTransaction added successfully!")
            break

        elif add_choice == "5":
        
            while True:
                try:
                    amount = float(input("Enter amount of groceries : "))
                except ValueError:
                    print("\nPlease input numeric value!\n")
                    continue
                else:
                    break

            is_today_func()
                    
        
            transactions["Other Expense"].append({"amount" : amount, "date" : date})
            save_transactions()
            print("\nTransaction added successfully!")
            break

        elif add_choice == "6":
        
            while True:
                try:
                    amount = float(input("Enter amount of other income : "))
                except ValueError:
                    print("\nPlease input numeric value!\n")
                    continue
                else:
                    break

            is_today_func()
        
            transactions["Other Income"].append({"amount" : amount, "date" : date})
            save_transactions()
            print("\nTransaction added successfully!")
            break

        else:
            print("\nPlease Enter valid range number!")

        

def view_transactions():
    global transactions
    while True:
        print("1. Groceries")
        print("2. Salary")
        print("3. Utilities")
        print("4. Transport")
        print("5. Other Expense")
        print("6. Other Income")

        try:
            view_choice = int(input("\nPlease select the category to view the transactions : "))
        except ValueError:
            print("\nInvalid Input! Please input valid number\n")
            continue

        number = 1
        if view_choice == 1:
            if "Groceries" in transactions:
                print("|Groceries Transactions|")
                num = 1
                for transaction in transactions["Groceries"]:
                    print(number, ".", "Date:",transaction["date"], ", Amount:", transaction["amount"])
                    number += 1
            else:
                print("No transactions found for groceries")
            break

        if view_choice == 2:
            if "Salary" in transactions:
                print("|Salary Transactions|")
                num = 1
                for transaction in transactions["Salary"]:
                    print(number, ".", "Date:",transaction["date"], ", Amount:", transaction["amount"])
                    number += 1
            else:
                print("No transactions found for salary")
            break

        if view_choice == 3:
            if "Utilities" in transactions:
                print("|Utilities Transactions|")
                num = 1
                for transaction in transactions["Utilities"]:
                    print(number, ".", "Date:",transaction["date"], ", Amount:", transaction["amount"])
                    number += 1
            else:
                print("No transactions found for utilities")
            break

        if view_choice == 4:
            if "Transport" in transactions:
                print("|Transport Transactions|")
                num = 1
                for transaction in transactions["Transport"]:
                    print(number, ".", "Date:",transaction["date"], ", Amount:", transaction["amount"])
                    number += 1
            else:
                print("No transactions found for transport")
            break

        if view_choice == 5:
            if "Other Expense" in transactions:
                print("|Other Expense Transactions|")
                num = 1
                for transaction in transactions["Other Expense"]:
                    print(number, ".", "Date:",transaction["date"], ", Amount:", transaction["amount"])
                    number += 1
            else:
                print("No transactions found for other expense")
            break


        if view_choice ==  6:
            if "Other Income" in transactions:
                print("|Other Income Transactions|")
                num = 1
                for transaction in transactions["Other Income"]:
                    print(number, ".", "Date:",transaction["date"], ", Amount:", transaction["amount"])
                    number += 1
            else:
                print("No transactions found for other income")
            break


        else:
           print("Please input valid range number")
    
        
def update_transaction():
    global transactions

    # Displaying transaction categories
    print("Transaction Categories:")
    print("1. Groceries")
    print("2. Salary")
    print("3. Utilities")
    print("4. Transport")
    print("5. Other Expense")
    print("6. Other Income")

    try:
        category_choice = int(input("Select the category to update transaction: "))
    except ValueError:
        print("Invalid input! Please enter a valid number.")
        return

    # Checking if the selected category exists
    if category_choice not in range(1, 7):
        print("Invalid category choice!")
        return

    # Selecting the transaction to update
    view_transactions()
    try:
        transaction_number = int(input("Enter the transaction number to update: "))
    except ValueError:
        print("Invalid input! Please enter a valid number.")
        return

    category = ""
    if category_choice == 1:
        category = "Groceries"
    elif category_choice == 2:
        category = "Salary"
    elif category_choice == 3:
        category = "Utilities"
    elif category_choice == 4:
        category = "Transport"
    elif category_choice == 5:
        category = "Other Expense"
    elif category_choice == 6:
        category = "Other Income"
    
    # Checking if the selected transaction number is valid
    if transaction_number not in range(1, len(transactions[category]) + 1):
        print("Invalid transaction number!")
        return

    # Updating the transaction amount
    try:
        new_amount = float(input("Enter the new amount: "))
    except ValueError:
        print("Invalid input! Please enter a valid amount.")
        return

    transactions[category][transaction_number - 1]["amount"] = new_amount
    print("Transaction updated successfully!")
    save_transactions()

           
def delete_transaction():
    global transactions

    # Displaying transaction categories
    print("Transaction Categories:")
    print("1. Groceries")
    print("2. Salary")
    print("3. Utilities")
    print("4. Transport")
    print("5. Other Expense")
    print("6. Other Income")

    try:
        category_choice = int(input("Select the category to delete transaction: "))
    except ValueError:
        print("Invalid input! Please enter a valid number.")
        return

    # Checking if the selected category exists
    if category_choice not in range(1, 7):
        print("Invalid category choice!")
        return

    category = ""
    if category_choice == 1:
        category = "Groceries"
    elif category_choice == 2:
        category = "Salary"
    elif category_choice == 3:
        category = "Utilities"
    elif category_choice == 4:
        category = "Transport"
    elif category_choice == 5:
        category = "Other Expense"
    elif category_choice == 6:
        category = "Other Income"

    # Viewing transactions of the selected category
    view_transactions()

    try:
        transaction_number = int(input("Enter the transaction number to delete: "))
    except ValueError:
        print("Invalid input! Please enter a valid number.")
        return

    # Checking if the selected transaction number is valid
    if transaction_number not in range(1, len(transactions[category]) + 1):
        print("Invalid transaction number!")
        return

    # Deleting the transaction
    del transactions[category][transaction_number - 1]
    print("Transaction deleted successfully!")
    save_transactions()



def display_summary():
    global transactions
    total_income = 0
    total_expense = 0

    # Calculate total income
    if "Salary" in transactions:
        for transaction in transactions["Salary"]:
            total_income += transaction["amount"]

    if "Other Income" in transactions:
        for transaction in transactions["Other Income"]:
            total_income += transaction["amount"]

    # Calculate total expense
    if "Groceries" in transactions:
        for transaction in transactions["Groceries"]:
            total_expense += transaction["amount"]

    if "Utilities" in transactions:
        for transaction in transactions["Utilities"]:
            total_expense += transaction["amount"]

    if "Transport" in transactions:
        for transaction in transactions["Transport"]:
            total_expense += transaction["amount"]

    if "Other Expense" in transactions:
        for transaction in transactions["Other Expense"]:
            total_expense += transaction["amount"]

    # Print summary
    print("\n--- Summary ---")
    print("Total Income:", total_income)
    print("Total Expense:", total_expense)
    print("Net Balance:", total_income - total_expense)

def luanch_gui():
    class FinanceTrackerGUI:
        def __init__(self, root):
            self.root = root
            self.root.title("Personal Finance Tracker")

            # Label for head
            heading = ttk.Label(root, text = "TRANSACTIONS", font = "arial 15 bold")    
            heading.pack(side = "top")

            self.create_widgets()
            self.transactions = self.load_transactions("transactions.json")
    
            self.display_transactions()

        def create_widgets(self):
            # Frame for table and scrollbar
            table_frame = ttk.Frame(self.root)
            table_frame.pack(padx=10, pady=10)

            # Treeview for displaying transactions
            self.table = ttk.Treeview(table_frame, columns=("Category", "Amount", "Date"), show="headings")
            self.table.heading("Category", text="Category")
            self.table.heading("Amount", text="Amount")
            self.table.heading("Date", text="Date")
            self.table.pack(side="left")
    
            # Scrollbar for the Treeview
            scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=self.table.yview)
            scrollbar.pack(side="right", fill="y")
            self.table.configure(yscrollcommand=scrollbar.set)

            # Search Entry and Button
            search_frame = ttk.Frame(self.root)
            search_frame.pack(padx=10, pady=(0, 10), fill="x")
            self.search_entry = ttk.Entry(search_frame, width=20)
            self.search_entry.pack(side="left")
            search_button = ttk.Button(search_frame, text="Search", command=self.search_transactions)
            search_button.pack(side="left", padx=(5, 0))

            # Column sorting bindings
            self.table.bind("<Button-1>", self.sort_by_column)

        def load_transactions(self, filename):
            try:
                with open(filename, "r") as file:
                    return json.load(file)
            except FileNotFoundError:
            # Create an empty JSON file if it does not exist
                with open(filename, "w") as file:
                    json.dump({}, file)
                return {}


        def display_transactions(self):
        
            # Remove existing entries
            for row in self.table.get_children():
                self.table.delete(row)
            
            # Add transactions to the treeview
            for category, category_transactions in self.transactions.items():
                for transaction in category_transactions:
                    amount = transaction["amount"]
                    date = transaction["date"]      
                    self.table.insert("", "end", values=(category, amount, date))
                
        def search_transactions(self):
    
            query = self.search_entry.get().lower()
            if not query:
                self.display_transactions()
                return
    
        # get an emty list to transactions
            results = []
    
            for category, category_transactions in self.transactions.items():
                for transaction in category_transactions:
                    if query in category.lower() or query in str(transaction["amount"]) or query in transaction["date"]:
                        transaction_with_category = {"category": category, **transaction}
                        results.append(transaction_with_category)
    
        # Display the search result
            self.display_search_results(results)


        def display_search_results(self, results):
        # Clear existing entries in the table
            for row in self.table.get_children():
                self.table.delete(row)

        # Insert search results into the table
            for transaction in results:
                category = transaction.get("category", "")
                amount = transaction.get("amount", "")
                date = transaction.get("date", "")
                self.table.insert("", "end", values=(category, amount, date))


        def sort_by_column(self, event):
            # Placeholder for sorting functionality        
            col = self.table.identify_column(event.x).split("#")[-1]
    
            if col == "1":
                sorted_data = sorted(self.transactions, key=lambda x: x["Category"])
            elif col == "2":
                sorted_data = sorted(self.transactions, key=lambda x: x["Amount"])
            elif col == "3":
                sorted_data = sorted(self.transactions, key=lambda x: x["Date"])
            else:
                return
        
            if str(self.table.heading(col, "option")["text"]) == "▲":
                sorted_data.reverse()
                self.table.heading(col, text=self.table.heading(col, "option")["text"].replace("▲", "▼"))
            else:
                self.table.heading(col, text=self.table.heading(col, "option")["text"].replace("▼", "▲"))
            # Display sorted data
            self.display_search_results(sorted_data)

    def main():
            root = tk.Tk()
            app = FinanceTrackerGUI(root)
            root.mainloop()

    if __name__ == "__main__":
        main()


def main_menu():
    load_transactions()
    read_bulk_transactions_from_file("filename.txt")
    while True:
        print("\n1. Add transaction")
        print("2. View transactions")
        print("3. Update transaction")
        print("4. Delete transaction")
        print("5. Display summary")
        print("6. Launch GUI")
        print("7. Exit")
        choice = input("\nPlease enter your choice : ")

        if choice == '1':
            add_transaction()
        elif choice == '2':
            view_transactions()
        elif choice == '3':
            update_transaction()
        elif choice == '4':
            delete_transaction()
        elif choice == '5':
            display_summary()
        elif choice == '6':
            luanch_gui()
        elif choice == '7':
            print("Exiting program.")
            break
        else:
            print("\nInvalid input!\nPlease enter valid range numeric number.")

if __name__ == "__main__":
    main_menu()


